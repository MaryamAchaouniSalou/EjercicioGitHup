package edu.alonso.tema1;

public class daw1 {
	public static void main(String[] args) {
		//int edadAlumno = 21;
		
		int edadAlumno;
		edadAlumno = 21;
		
		System.out.println("edad del alumno:" + edadAlumno +"años");
	}

}
